import sys, urllib2, urllib, os, re, base64
try:
    import json
except:
    import simplejson as json


import cookielib

USER_AGENT = "Mozilla/5.0 (iPad; CPU OS 5_1 like Mac OS X; en-us) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B176 Safari/7534.48.3"

def mod_request(url, referer = None):
    try:
        cookie_jar = cookielib.CookieJar()
        #cookie_jar = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie_jar))
        opener.addheaders = [("User-Agent", USER_AGENT)]
        if referer is not None:
            opener.addheaders = [("Referer", referer)]
        connection = opener.open(url)
        html = connection.read()
        #cookie_jar.save(cookiefile, ignore_discard = True)
        connection.close()
        return html
    except:
        return ''

class sg_parsers:

    def __init__(self):
        self.quality = ''

    def get_parsed_link(self, url):
        try:
            if url.find('/serial') > -1 and url.find('/iframe') > -1:
                print "serialmoonwalk"
                ref = ''
                if url.find('@') > -1:
                    url = url.split('@')[0]
                    ref = '@http://moonwalk.cc'
                try:
                    page = mod_request(url)
                    code = re.findall("video_token: '(.*)',", page)
                    if len(code) > 0:
                        url = 'http://moonwalk.cc/video/' + code[0] + '/iframe' + ref
                except Exception as ex:
                    print ex

            if url.find('/iframe') > -1:
                #ref = 'http://moonwalk.cc'
                #ref = url + '?show_embed=1'
                if url.find('@') > -1:
                    parts = url.split('@')
                    url = parts[0]
                    # ref = parts[1]
                    #ref = parts[0] + '?show_embed=1'
                url = 'http://ltcam4.ddns.net/moonwalk.php?url=' + urllib.quote(url)
                request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 nStreamVOD 0.1', 'Connection': 'Close'})
                try:
                    #url = ''
                    url = urllib2.urlopen(request).read().replace('\n', '')
                    """for url in urls.split('\n'):
                        if 'tracks-1,' in url:
                            break
                    if url == '':
                        for url in urls.split('\n'):
                            if 'tracks-2,' in url:
                                break"""
                    #url = url.split('\n')[len(url.split('\n'))-3]
                    # csrftoken = re.findall(r'csrf-token" content="(.*?)"',page)
                    # csrftoken = csrftoken[0]
                    # video_token = re.findall(r"video_token: '(.*?)'",page)
                    # video_token = video_token[0]
                    # content_type = re.findall(r"content_type: '(.*?)'",page)
                    # content_type = content_type[0]
                    # access_key = re.findall(r"mw_key: '(.*?)'",page)
                    # access_key = access_key[0]
                   # # access_key = access_key[:3] + urllib.urlencode(access_key[4]) + access_key[4:]
                    # mw_pid = re.findall(r'mw_pid: (.*?),', page)
                    # mw_pid = mw_pid[0]
                    # mw_domain_id = re.findall(r'p_domain_id: ([0-9]*)', page)
                    # mw_domain_id = mw_domain_id[0]
                    # # uuid = re.findall(r"uuid: '(.*?)'",page)
                    # # uuid = uuid[0]
                    # ifnot = re.findall("var version_control = '(.*?)';",page)
                    # ifnot = ifnot[0]
                    # print "mooooooonwalk" 
                    # params = {'mw_pid':mw_pid,'p_domain_id':mw_domain_id, 'video_token':video_token, 'content_type':content_type, 'mw_key':access_key, 'ad_attr':'0', 'debug':'false', 'version_control':ifnot} 
                    # url1 = "http://moonwalk.cc/sessions/new_session"
                    # params = urllib.urlencode(params)
                    # headers22 = {'X-Condition-Safe': 'Normal', 'X-Requested-With': 'XMLHttpRequest', "X-CSRF-Token": csrftoken, 'Referer': url, 'User-agent': 'Mozilla/5.0 (Windows NT 6.1; rv:38.0) Gecko/20100101 Firefox/38.0'}
                    # request = urllib2.Request(url1, params, headers22)
                    # page = urllib2.urlopen(request).read()
                    # url = re.findall(r'manifest_m3u8":"(.*?)"',page)
                    # url = url[0]
                    # url = url.replace("u0026","&")
                    # url = url.replace("\\","")
                except Exception, ex:
                    print ex
                        
            if url.find('filmux.org') > -1:
                if url.find('md5hash') > -1 and url.find('@') > -1:
                    ur = url.split('@')
                    url = ur[0]
                    uri = ur[1]
                    if len(ur) > 2:
                        cookie = ur[2]
                    #request = urllib2.Request(uri, None, {'User-agent': 'Mozilla/5.0 nStreamVOD 0.1', 'Connection': 'Close'})
                    try:
                        #page = urllib2.urlopen(request).read()
                        try:
                            mod_request('https://servicer.marketgid.com/655887/2?w=362&h=167&cols=1&pv=5&cbuster=1535564731300236526132&ref=&lu=https://filmux.org/&pageView=1&pvid=16586ca53a4926d024f&muid=i7t1QQekG3Bk', 'https://filmux.org/')
                            mod_request('https://servicer.marketgid.com/655021/2?w=422&h=664&cols=1&pv=5&cbuster=1535564731700548124764&ref=&lu=https://filmux.org/&pageView=0&pvid=16586ca553486997718&muid=i7t1QQekG3Bk', 'https://filmux.org/')
                        except:
                            pass
                        page = mod_request(uri, 'https://filmux.org')
                        md5 = re.findall("file(?:'|):'(.*?)'", page)
                        md5hash = md5[0].split('/')[4]
                        url = url.replace('md5hash', md5hash)
                        if len(ur) > 2:
                            url = url + '|Cookie=' + cookie
                    except Exception as ex:
                        print ex
                elif url.find('@') > -1:
                    ur = url.split('@')
                    url = ur[0]
                    cookie = ur[1]
                    url = url + '|Cookie=PHPSESSID=' + cookie
                else:
                    #request = urllib2.Request(url.replace('http:', 'https:'), None, {'User-agent': 'Mozilla/5.0 nStreamVOD 0.1', 'Connection': 'Close'})
                    try:
                        #page = urllib2.urlopen(request).read()
                        page = mod_request(url.replace('http:', 'https:'), 'https://filmux.org')
                        a = re.findall('://srv(.*?)"', page)[0]
                        #request1 = urllib2.Request('https://srv'+a, None, {'User-agent': 'Mozilla/5.0 nStreamVOD 0.1', 'Connection': 'Close'})
                        #page1 = urllib2.urlopen(request1).read()
                        page1 = mod_request('https://srv'+a, 'https://filmux.org')
                        url = re.findall("file:'(.*?)'", page1)[0]
                    except Exception as ex:
                        print ex
                        
            if url.find("borfilm.com@") > -1: # tfilm -> borfilm.com
                e2 = url.split('@')[2]
                url = url.split('@')[1]
                
                request = urllib2.Request(e2, None, {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36',
                                                        #'Connection': 'keep-alive',
                                                        "Host": "borfilm.com",
                                                        "Referer": e2,
                                                    })
                
                try:
                    page = urllib2.urlopen(request).read()
                    iframe = re.findall('<iframe.*src="(.*?)".*</iframe>', page)
                    if iframe != []:
                        tmp = iframe[0]
                        request1 = urllib2.Request(tmp, None, {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36',
                                                        #'Connection': 'keep-alive',
                                                        "Host": "play.abertu.com",
                                                        #"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
                                                        "Referer": e2,
                                                    })
                        responseget = urllib2.urlopen(request1).read()
                        code = ''
                        fcode = re.findall('file:"(.*?)"', responseget)
                        pcode = re.findall('pl:"(.*?)"', responseget)
                        if (fcode != []): 
                            code = fcode[0]
                            url = code
                        elif (pcode != []):
                            code = pcode[0]
                            hash = re.findall("/dl/(.*?)/", code)[0]
                            url = url.replace("md5hash", hash)
                except Exception as ex:
                        print ex
                    
            if url.find('https://lib.lrytas.lt/geoip/get_token_live.php') > -1:
                url = mod_request(url).replace('\n', '')
					
        except Exception as ex:
            print ex
            print 'sgparsed_link=' , url
        print 'sgparsedurl=' , url
        return url

