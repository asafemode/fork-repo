import sys, urllib2, urllib, os, re, base64
try:
    import json
except:
    import simplejson as json


import cookielib

USER_AGENT = "Mozilla/5.0 (iPad; CPU OS 5_1 like Mac OS X; en-us) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B176 Safari/7534.48.3"

def mod_request(url, referer = None):
    try:
        cookie_jar = cookielib.CookieJar()
        #cookie_jar = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie_jar))
        opener.addheaders = [("User-Agent", USER_AGENT)]
        if referer is not None:
            opener.addheaders = [("Referer", referer)]
        connection = opener.open(url)
        html = connection.read()
        #cookie_jar.save(cookiefile, ignore_discard = True)
        connection.close()
        return html
    except:
        return ''

class sg_parsers:

    def __init__(self):
        self.quality = ''

    def get_parsed_link(self, url):
        try:
            if url.find('filmux.net') > -1:
                if url.find('md5hash') > -1 and url.find('@') > -1:
                    ur = url.split('@')
                    url = ur[0]
                    uri = ur[1]
                    if len(ur) > 2:
                        cookie = ur[2]
                    #request = urllib2.Request(uri, None, {'User-agent': 'Mozilla/5.0 nStreamVOD 0.1', 'Connection': 'Close'})
                    try:
                        #page = urllib2.urlopen(request).read()
                        try:
                            mod_request('https://servicer.marketgid.com/655887/2?w=362&h=167&cols=1&pv=5&cbuster=1535564731300236526132&ref=&lu=https://filmux.net/&pageView=1&pvid=16586ca53a4926d024f&muid=i7t1QQekG3Bk', 'https://filmux.net/')
                            mod_request('https://servicer.marketgid.com/655021/2?w=422&h=664&cols=1&pv=5&cbuster=1535564731700548124764&ref=&lu=https://filmux.net/&pageView=0&pvid=16586ca553486997718&muid=i7t1QQekG3Bk', 'https://filmux.net/')
                        except:
                            pass
                        page = mod_request(uri, 'https://filmux.net')
                        md5 = re.findall("file(?:'|):'(.*?)'", page)
                        md5hash = md5[0].split('/')[4]
                        url = url.replace('md5hash', md5hash)
                        if len(ur) > 2:
                            url = url + '|Cookie=' + cookie
                    except Exception as ex:
                        print ex
                elif url.find('@') > -1:
                    ur = url.split('@')
                    url = ur[0]
                    cookie = ur[1]
                    url = url + '|Cookie=PHPSESSID=' + cookie
                else:
                    #request = urllib2.Request(url.replace('http:', 'https:'), None, {'User-agent': 'Mozilla/5.0 nStreamVOD 0.1', 'Connection': 'Close'})
                    try:
                        #page = urllib2.urlopen(request).read()
                        page = mod_request(url.replace('http:', 'https:'), 'https://filmux.net')
                        a = re.findall('://srv(.*?)"', page)[0]
                        #request1 = urllib2.Request('https://srv'+a, None, {'User-agent': 'Mozilla/5.0 nStreamVOD 0.1', 'Connection': 'Close'})
                        #page1 = urllib2.urlopen(request1).read()
                        page1 = mod_request('https://srv'+a, 'https://filmux.net')
                        url = re.findall("file:'(.*?)'", page1)[0]
                    except Exception as ex:
                        print ex
                        
            if url.find('https://lib.lrytas.lt/geoip/get_token_live.php') > -1:
                url = mod_request(url).replace('\n', '')
					
        except Exception as ex:
            print ex
            print 'sgparsed_link=' , url
        print 'sgparsedurl=' , url
        return url

