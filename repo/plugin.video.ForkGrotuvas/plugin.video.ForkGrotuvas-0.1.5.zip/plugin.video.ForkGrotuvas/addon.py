#!/usr/bin/env python
# -*- coding: utf-8 -*-
import urllib, urllib2, re, sys, os, random
import xbmcplugin, xbmcgui
import xbmcaddon
import xbmc
import codecs
Addon = xbmcaddon.Addon( id = 'plugin.video.ForkGrotuvas' )
_ADDON_PATH =   xbmc.translatePath(Addon.getAddonInfo('path'))
_ADDON_USERDATA_PATH = xbmc.translatePath(Addon.getAddonInfo("profile"))
sys.path.append( os.path.join( _ADDON_PATH, 'resources', 'lib'))
addon_id = Addon.getAddonInfo('id')
import VseTV
from m3u8parser import best_m3u8
from BeautifulSoup import BeautifulStoneSoup, MinimalSoup
from urllib import unquote_plus
from SGParser import sg_parsers
from demjson3 import loads
import socket
import time
    
hos = int(sys.argv[1])
xbmcplugin.setContent(hos, 'movies')
busystring = xbmc.getLocalizedString(503).encode("utf8")

fanart  = _ADDON_PATH + '/fanart.jpg'
set_png = _ADDON_PATH + '/installation.png'
left = _ADDON_PATH + '/left.png'
right = _ADDON_PATH + '/right.png'
addon_icon = _ADDON_PATH + '/icon.png'
ace_icon = _ADDON_PATH + '/ace.png'

bckKey = _ADDON_USERDATA_PATH + '/bckeyb.bk'

if not os.path.exists(_ADDON_USERDATA_PATH):
    os.makedirs(_ADDON_USERDATA_PATH)
if os.path.exists(bckKey) == False:
    os.path.dirname(bckKey)
    bckeyb = open(bckKey, 'w')
    bckeyb.write('')
    bckeyb.close()
    
def xt(x):return xbmc.translatePath(x)
def write_mac():
    mac_settings = Addon.getSetting('mac')
    if mac_settings == "":   
        mac_address = xbmc.getInfoLabel('Network.MacAddress')
        i = 1
        while mac_address == busystring:
            print "while: %s" % i
            i = i+1
            mac_address = xbmc.getInfoLabel('Network.MacAddress') 
            time.sleep(1)
            if i == 10:
                break
        Addon.setSetting('mac', mac_address)

def showMessage(message = '', heading='', times = 5000, pics=''):
    try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading.encode('utf-8'), message.encode('utf-8'), times, pics.encode('utf-8')))
    except Exception, e:
        #xbmc.log( '[%s]: showMessage: Transcoding UTF-8 failed [%s]' % (addon_id, e), 2 )
        try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
        except Exception, e:
            xbmc.log( '[%s]: showMessage: exec failed [%s]' % (addon_id, e), 3 )

#agent = xbmc.getUserAgent()
agent = 'XBMC ForkGrotuvas'
xbmc_headers = {'User-Agent': agent}

def construct_request(params):
    return '%s?%s' % (sys.argv[0], urllib.urlencode(params))

def GET(target, post=None):
    try:
        req = urllib2.Request(url = target, data = post)
        req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
        req.add_header('Accept', '*/*')
        req.add_header('Accept-Language', 'ru-RU')
        req.add_header('Accept-Charset', 'utf-8')
        resp = urllib2.urlopen(req)
        http = resp.read()
        resp.close()
        return http
    except Exception as ex:
        print ex

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def ace_play(url):
	try:
	    progressBar = xbmcgui.DialogProgress()
	    progressBar.create('ACE Stream', 'Paleidimas')
	    srv = Addon.getSetting("p2p_serv")#'127.0.0.1'
	    prt = Addon.getSetting("p2p_port")#'6878'
	    host = mfind(url, '//', '/a')
	    url = url+'&format=json&_idx='
	    link = url.replace(host, ''+srv+':'+prt+'')
	    if '/ace/getstream?' in url: 
	      json=eval(GET(link).replace('null','"null"'))["response"]
	      if json == 'null': return
	      progressBar.update(0, 'ACE Stream', 'Rastas šaltinis', "")
	      stat_url=json["stat_url"]
	      stop_url=json["command_url"]+'?method=stop'
	      purl=json["playback_url"]
	      """progressBar.update(0, 'ACE Stream', 'Prisijungimas', "")
	      return purl"""
	      while not xbmc.abortRequested:
	          xbmc.sleep(300)
	          j=eval(GET(stat_url).replace('null','"null"'))["response"]
	          if j=={}:
	              pass
	              progressBar.update(0, 'ACE Stream', 'Laukimas', "")
	          else:
	              status=j['status']
	              if status=='dl': break
	              try:
	                  download=j['downloaded']
	                  progress=j['total_progress']
	                  seeds=j['peers']
	                  speed=j['speed_down']
	                  progressBar.update(progress*10, xt('Buferizacija: '+str(download/1024/1024)+" MB"), "Sidai: "+str(seeds), "Greitis: "+str(speed)+' Kbit/s')
	              except: pass
	          if progressBar.iscanceled():    
	              progressBar.update(0)
	              progressBar.close()
	              GET(stop_url)
	              return
	      progressBar.update(0)
	      progressBar.close()
	      return purl
	except:
		return ''


def ace_start():
	srv = Addon.getSetting("p2p_serv")#'127.0.0.1'
	prt = Addon.getSetting("p2p_port")#'6878'
	lnk = 'http://'+srv+':'+prt+'/webui/api/service?method=get_version&format=jsonp&callback=mycallback'
	resp = GET(lnk)
	if resp > 0:
	  return True  	
	else:	
	  	showMessage('Cant find Ace proxy', ''+srv+':'+prt+'', 5000, ace_icon)
	return False      
	    
def ace_post():
    try:
        sp = Addon.getSetting("p2p_sp")#'127.0.0.1:6878'
        url = 'http://78.58.97.191/p2p/serv.php'
        values = {'post_ip': sp}
        headers = {'User-Agent': agent}
        data = urllib.urlencode(values)
        req = urllib2.Request(url, data, headers)
        resp = urllib2.urlopen(req)
        http = resp.read()
        resp.close()
        return http
    except Exception as ex:
        print ex

def Pars(url):
    try:
        if url.find('|') > -1:
            dolc = url.split('|')
            uri = dolc[0]
            pars1 = dolc[1]
            pars2 = dolc[2]
            headers = {
                            'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
                            'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-us,en;q=0.5',
                        }
            if '@' in uri:
                spl = uri.split('@')
                uri = spl[0]
                referer = spl[1]
                headers = {
                                'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
                                'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-us,en;q=0.5',
                                'Referer': referer,
                            }
            req = urllib2.Request(uri, None, headers)
            html = urllib2.urlopen(req).read().replace('\t', '').replace('\r', '').replace('\n', '')
            if pars1.find(".*?") > -1 or pars2.find(".*?") > -1:
                p = re.findall(pars1 + '(.*?)' + pars2, html)
                if p != []:
                    return p[0]
            else:
                html = html.replace(pars1, '<@@parser>').replace(pars2, '</@@parser>')
                regex = re.findall('<@@parser>(.*?)</@@parser>', html)
                if regex != []:
                    return regex[0]
                else:
                    return None
        else:
            return url
    except Exception as ex:
        print 'Pars error', ex
        return None
          
def Categories(params):
    s = ''############################################################
    start = 'https://tinyurl.com/y68gcufe'
    """if Addon.getSetting('start') != None and Addon.getSetting('start') != '':
        start = Addon.getSetting('start')"""
    if Addon.getSetting('p2p_sp') != '':
        ace_post()
    if Addon.getSetting('mac') != None and Addon.getSetting('mac') != '':
        box_mac = Addon.getSetting('mac')
    else:
        box_mac = ''
    try:
        searchon = params['search']
    except:
        searchon = None
    try:
        url = urllib.unquote(params['link'])
    except Exception as ex:
        print 'error link = ', ex
        url = start

    try:
        parser = params['parser']
        if parser:
            strUrl = Pars(parser)
            if strUrl and url:
                if url.find('md5hash') > -1:
                    url = url.replace('md5hash', strUrl)
    except Exception as ex:
        print 'error parser = ', ex

    sign = '?'
    if url.find('?') > -1:
        sign = '&'
    cmd = xbmc_headers
    url = url + sign + 'box_mac=' + box_mac

    if searchon == 'search':
        cache = url
        kbd = xbmc.Keyboard()
        values = []
        sts = ''
        bc = open(bckKey, 'r')
        lines = bc.readlines()
        bc.close()
        ask = xbmcgui.Dialog()
        qestion = ['[COLOR FFFFFF44]Nauja paieška[/COLOR]']
        for line in lines:
            qestion.append(line)
        sel = ask.select('[COLOR FFFF8888]Nauja, arba jau ieškotų frazių paieška[/COLOR]', qestion)
        print '===sel===', sel
        if sel == 0:
            kbd.setDefault(sts)
            kbd.setHeading('Search')
            kbd.doModal()
            if kbd.isConfirmed():
                sts=kbd.getText();
                sts = sts.replace(' ','%20')
                if sts != '':
                    count = 0
                    bc = open(bckKey, 'w')
                    bc.write(sts + '\n')
                    for line in lines:
                        count += 1
                        if line.strip('\n') != sts and len(line) > 2 and count < 10:
                            bc.write(line.replace('%20',' '))
                    bc.close()
        elif sel != -1:
            sts = qestion[sel].replace(' ', '%20').strip('\n')
            bc = open(bckKey, 'w')
            bc.write(sts + '\n')
            for line in lines:
                if line.strip('\n') != sts:
                    bc.write(line.replace('%20',' '))
            
        if sts != '':
            url = url + '&search=' + sts
        else:
            url = cache


    http = ''
    #####################
    try:
        req = urllib2.Request(url, None, cmd)
        http = urllib2.urlopen(req).read()
    except Exception as ex:
        print 'urllib2 error -> ' , ex
    #############################
    http = http.replace('&nbsp;', ' ').replace('&amp;', '&')

    if http != None and http != '':
        if http.find('#EXT') > -1:
            m3u(http)
        else:
            xml = BeautifulStoneSoup(http)
            n = 0
            playlist(xml)
    if url == start + sign + 'box_mac=' + box_mac:
        uri = construct_request({
            'func': 'settings'
            })
        listitem=xbmcgui.ListItem('[COLOR FFFF8888]Nustatymai[/COLOR]', iconImage = set_png)
        listitem.setInfo(type = 'settings', infoLabels={})
        listitem.setProperty('fanart_image', set_png)
        xbmcplugin.addDirectoryItem(hos, uri, listitem, True)
    if Addon.getSetting('list') == '0':
        xbmc.executebuiltin('Container.SetViewMode(504)')
    if Addon.getSetting('list') == '1':
        xbmc.executebuiltin('Container.SetViewMode(500)')
    if Addon.getSetting('list') == '2':
        xbmc.executebuiltin('Container.SetViewMode(503)')
    if Addon.getSetting('list') == '3':
        xbmc.executebuiltin('Container.SetViewMode(515)')
    if Addon.getSetting('list') == '4':
        xbmc.executebuiltin('Container.SetViewMode(501)')
    xbmcplugin.endOfDirectory(hos)



def playlist(xml):
    n = 0
    link = None
    stream = None
    prev_title = ''
    next_title = ''
    construkt = {}
    prev_page_element = xml.find('prev_page_url')
    if prev_page_element:
        prev_url = prev_page_element.text.encode('utf-8')
        prev_page_text = prev_page_element.get('text')
        if prev_page_text:
            prev_page_text = prev_page_text.encode('utf-8')
            prev_title =  "[COLOR FFFFFF00]<-" + prev_page_text +'[/COLOR]'
            uri = construct_request({
                 'func': 'Categories',
                 'link':prev_url
                 })
            listitem=xbmcgui.ListItem(prev_title)
            listitem.setProperty('Fanart_Image', left)
            xbmcplugin.addDirectoryItem(hos, uri, listitem, True)
    next_page_element = xml.find('next_page_url')
    if next_page_element:
        next_url = next_page_element.text.encode('utf-8')
        next_page_text = next_page_element.get('text')
        if next_page_text:
            next_page_text = next_page_text.encode('utf-8')
            next_title =  "[COLOR FFFFFF00]->" + next_page_text +'[/COLOR]'
            uri = construct_request({
                'func': 'Categories',
                'link':next_url
                })
            listitem=xbmcgui.ListItem(next_title)
            listitem.setProperty('fanart_image', right)
            xbmcplugin.addDirectoryItem(hos, uri, listitem, True)

    for channel in xml.findAll('channel'):
        img_src = ''
        img_logo = ''
        description = ''
        titl = ''
        epg = ''
        title = channel.find('title').text.encode('utf-8')
        title = title.replace('&amp;', '&').replace('&nbsp;', ' ').replace('\t', '').replace('\r', '').replace('\n', '')
        if 'color="' in title and "#" in title:
            title = title.replace('#', '')
            rep = re.findall('(<font.*?)<', title)
            des = re.findall('color="(.*?)".*?>(.*?)<', title)
            if rep != [] and des != []:
                for r, d in zip(rep, des):
                    title = title.replace(r,'[COLOR ff'+d[0]+']'+d[1]+'[/COLOR]')
        title = re.compile('<[\\/\\!]*?[^<>]*?>').sub('', title)
        title = title.replace('</font', '')
        description = channel.find('description')
        if description:
            description = description.text.encode('utf-8')
            img_src_list = re.findall('src="(.*?)"', description) or re.findall("src='(.*?)'", description)
            if len(img_src_list) > 0:
                img_src = img_src_list[0]
            if img_src == None or img_src == '' or img_src.find('http') < 0 :
                img_src = fanart
            description = description.replace('<br>', '\n')
            description = description.replace('<br/>', '\n')
            description = description.replace('&amp;', '&').replace('&nbsp;', ' ').replace('\t', '').replace('\r', '').replace('\n', '')
            if 'color="' in description and  "#" in description:
                description = description.replace('#', '')
                repl = re.findall('(<font.*?)<', description)
                desc = re.findall('color="(.*?)".*?>(.*?)<', description)
                if repl != [] and desc != []:
                    for r, d in zip(repl, desc):
                        description = description.replace(r,'[COLOR ff'+d[0]+']'+d[1]+'[/COLOR]')
            description = re.compile('<[\\/\\!]*?[^<>]*?>').sub('', description)
            description = description.replace('</font', '')
        else:
            description = title
        if description == '':
            description = title
        piconname = channel.find('logo_30x30') or channel.find('logo')
        if piconname:
            img_logo = piconname.text
            if img_src == None or img_src == '' or img_src == fanart :
                img_src = img_logo

        n = n+1

        searchon = channel.find('search_on')
        search = None
        if searchon:
            search = searchon.text.encode('utf-8')
            
        parser = channel.find('parser')
        if parser:
            parser = parser.text.encode('utf-8')
        stream_url = channel.find('stream_url')
        playlist_url = channel.find('playlist_url')
        
        if playlist_url:
            link = playlist_url.text.encode('utf-8')
            titl = "[COLOR FFFFFFFF]" + title + "[/COLOR]"
            
            construkt = {
                'func': 'Categories',
                'link': link,
                'search': search,
                'parser': parser
                }
                    
        if stream_url:
            stream = stream_url.text.encode('utf-8')
            titl = "[COLOR FFB77D00]" + title + "[/COLOR]"
            
            epg = VseTV.get_ch_id(title)
            if epg != None:
                img_src = 'http://vsetv.ru/pic/channel_logos/%s.gif' % epg
                 
            construkt = {
                'func': 'Play',
                'stream':stream,
                'img':img_src,
                'title':title,
                'epgid':epg,
                'parser':parser
                }
                
        listitem=xbmcgui.ListItem(titl, iconImage = img_src, thumbnailImage = img_src)
        listitem.setProperty('fanart_image', img_src)
        listitem.setInfo(type = 'video', infoLabels={'title': titl, 'plot': description})
        uri = construct_request(construkt)
        xbmcplugin.addDirectoryItem(hos, uri, listitem, True)


def m3u(m3u):
    lines = m3u.splitlines()
    for line in lines:
        if line.find('#EXTINF') > -1:
            img_src = 'http://185.25.119.98/epg/logo/0.png'
            titl = ''
            epg = ''
            text = re.findall('#EXTINF.*,(.*)', line)
            try:
                titl = text[0].strip()
            except:
                titl = ''
            title = "[COLOR FFFFB77D00]" + titl + "[/COLOR]"
            epg = VseTV.get_ch_id(titl)
            if epg != '' and epg != None:
                img_src = 'http://vsetv.ru/pic/channel_logos/%s.gif' % epg
            else:
                epg = ''
        if line.find(':/') > -1 and line.find('#EXT') < 0:
            str_url = ''
            url = re.findall('(.*:/.*)', line)
            str_url = url[0].strip()
            description = titl
            listitem=xbmcgui.ListItem(title, iconImage = img_src, thumbnailImage = img_src)
            listitem.setProperty('fanart_image', img_src)
            listitem.setInfo(type = 'video', infoLabels={'title': title, 'plot': description})
            uri = construct_request({
                'func': 'Play',
                'title':title,
                'img':img_src,
                'stream':str_url,
                'epgid':epg
                })
            xbmcplugin.addDirectoryItem(hos, uri, listitem, True)


def settings(params):
    Addon.openSettings()
    return None

def Play(params):
    global SG_PARSER
    SG_PARSER = sg_parsers()
    try:
        epgid = params['epgid']
    except:
        epgid = None
    
    try:
        url = urllib.unquote(params['stream']).replace('&amp;', '&').replace(';', '')
    except:
        url = ''
        
    url = url.replace(' ', '%20')
        
    try:
        title = params['title']
    except:
        title = ''
    
    try:
        img = params['img']
    except:
        img = ''
        
    try:
        parser = params['parser']
    except:
        parser = None

    if epgid != '' and epgid != None:
        epg = VseTV.get_ch_epg(epgid)
        if epg != '' and epg != None:
            title = epg
    
    try:
        url = SG_PARSER.get_parsed_link(url)
        
        if parser != None:
            strUrl = Pars(parser)
            if url.find('md5hash') > -1 and strUrl:
                url = url.replace('md5hash', strUrl)
        
        if url.find('youtube') > -1:
            url = url.replace('embed/', 'watch?v=').replace('&feature', '').replace('=player_embedded', '').replace('?feature=player_detailpage', '')
            video_id = url.split('=')
            if len(video_id) > 1:
                xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid=' + url + ')')
                return
            else:
                return

        if url.find('.m3u8') > -1:
            url = best_m3u8(url)
            
        if url.find('/ace/getstream?') > -1:
          if ace_start() == True:  
            url = ace_play(url)
    
    except Exception as ex:
        print ex
    
    if url != '' and url != None and url.find('.html') < 0 and url.find('md5hash') < 0:
        i = xbmcgui.ListItem(title, title, img, img)
        xbmc.Player().play(url, i)
    else:
        showMessage('Not playable stream', url, 5000, addon_icon)

def get_params(paramstring):
    param=[]
    if len(paramstring)>=2:
        params=paramstring
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    if len(param) > 0:
        for cur in param:
            param[cur] = urllib.unquote_plus(param[cur])
    return param

params = get_params(sys.argv[2])

user_data = xbmc.translatePath('special://userdata')

autostart = Addon.getSetting('autostart')

if autostart == "0":
    autoex = open(user_data + 'autoexec.py', 'w')
    autoex.write("import xbmc\nxbmc.executebuiltin('XBMC.RunAddon(plugin.video.ForkGrotuvas)')\n")
    autoex.close()
else:
    autoex = open(user_data + 'autoexec.py', 'w')
    autoex.write("import xbmc\n#xbmc.executebuiltin('XBMC.RunAddon(plugin.video.ForkGrotuvas)')\n")
    autoex.close()

if Addon.getSetting('mac') == None or Addon.getSetting('mac') == '':
	write_mac()	

box_mac = Addon.getSetting('mac')

if Addon.getSetting('requestTimeOut') != None and Addon.getSetting('requestTimeOut') != '':
    req_time = Addon.getSetting('requestTimeOut')
    if req_time == '0':
        sreq_time = 10
    elif req_time == '1':
        sreq_time = 20
    elif req_time == '2':
        sreq_time = 30
    else:
        sreq_time = 60
    
    socket.setdefaulttimeout(sreq_time)
else:
    socket.setdefaulttimeout(30)
    
try:
    func = params['func']
    del params['func']
except:
    func = None
    xbmc.log( '[%s]: Primary input' % addon_id, 1 )
    Categories(params)
    
if func != None:
    try: pfunc = globals()[func]
    except:
        pfunc = None
        xbmc.log( '[%s]: Function "%s" not found' % (addon_id, func), 4 )
        showMessage('Internal addon error', 'Function "%s" not found' % func, 2000, addon_icon)
    if pfunc:
        pfunc(params)
