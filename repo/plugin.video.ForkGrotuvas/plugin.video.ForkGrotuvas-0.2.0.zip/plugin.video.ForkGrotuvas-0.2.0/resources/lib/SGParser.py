import sys, urllib2, urllib, os, re, base64
try:
    import json
except:
    import simplejson as json


import cookielib

USER_AGENT = "Mozilla/5.0 (iPad; CPU OS 5_1 like Mac OS X; en-us) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B176 Safari/7534.48.3"

def mod_request(url, referer = None):
    try:
        cookie_jar = cookielib.CookieJar()
        #cookie_jar = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie_jar))
        opener.addheaders = [("User-Agent", USER_AGENT)]
        if referer is not None:
            opener.addheaders = [("Referer", referer)]
        connection = opener.open(url)
        html = connection.read()
        #cookie_jar.save(cookiefile, ignore_discard = True)
        connection.close()
        return html
    except:
        return ''

class sg_parsers:

    def __init__(self):
        self.quality = ''

    def get_parsed_link(self, url):
        try:
            if url.find('filmux.net') > -1 or url.find('filmux.me') > -1:
                if url.find('md5hash') > -1 and url.find('@') > -1:
                    ur = url.split('@')
                    url = ur[0]
                    uri = ur[1]
                    if len(ur) > 2:
                        cookie = ur[2]
                    try:
                        host = url.split('/')[2]
                        request = urllib2.Request(uri, None, {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
                                                        "Host": host,
                                                        "Referer": uri,
                                                    })
                        page = urllib2.urlopen(request).read()
                        md5 = re.findall("file(?:'|):'(.*?)'", page)
                        md5hash = md5[0].split('/')[4]
                        url = url.replace('md5hash', md5hash)
                    except Exception as ex:
                        print ex
                
                        
            if url.find('https://lib.lrytas.lt/geoip/get_token_live.php') > -1:
                url = mod_request(url).replace('\n', '')
					
        except Exception as ex:
            print ex
            print 'sgparsed_link=' , url
        print 'sgparsedurl=' , url
        return url

