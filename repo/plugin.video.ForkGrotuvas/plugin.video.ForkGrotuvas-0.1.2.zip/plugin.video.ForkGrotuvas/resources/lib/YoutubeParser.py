import re
from urllib2 import Request, urlopen

class youtube_url:

    def get_youtube_link2(self, url):
        video_tulpe = []
        film_quality = []
        video_id = ''
        video_url = url
        error = None
        if url.find('youtube') > -1:
            split = video_url.split('=')
            if len(split) > 1:
                video_id = split[1]
                video_url = None
                try:
                    answer = (urlopen(Request('http://ltcam4.ddns.net/youtube/youtube_api.php?id=' + video_id, None, {'User-agent': 'Mozilla/5.0 nStreamVOD 0.1',
                                                                                                                         'Connection': 'Close'})).read())

                    reg = re.findall('<iframe src="(.*?)" quality="(.*?)">', answer)
                    for src, quality in reg:
                        if quality.find('webm') < 1 and quality.find('flv') < 1  and quality.find('vp8') < 1:
                            video_tulpe.append(src)
                            film_quality.append(quality)
                    #print video_tulpe, film_quality
                    if video_tulpe != [] and film_quality != []:
                        return video_tulpe[0]
                    else:
                        return ''
                except Exception as ex:
                    return ''
