# -*- coding: UTF-8 -*-

import re
import random
import urllib.request, urllib.parse, urllib.error
import http.cookiejar
import gzip
from urllib.parse import unquote_plus, quote_plus
import json

def getHostUrl(url):
    parsed_url=urllib.parse.urlparse(url)
    return parsed_url.scheme+"://"+parsed_url.netloc

def getFullUrl(url, base_url):
    if(url is None):
        return None

    parsed_url=urllib.parse.urlparse(base_url)
    
    if(url.startswith("//")):
        return parsed_url.scheme+":"+url
    elif(url.startswith("/")):
        return getHostUrl(base_url)+url
    elif(url.startswith("http:") is False and url.startswith("https:") is False):
        if(url.startswith("./")):
            url=url[2:]
        ret=parsed_url.scheme+"://"+parsed_url.netloc+parsed_url.path[:parsed_url.path.rindex("/")+1]+url
        return ret
    else:
        return url
        
def findall(tag, content):
    ret=[]
    p=r"<\s*"+tag+"\s*([^>]*?)>(.*?)<\s*\/"+tag+"\s*>"
    for item in re.findall(p, content, re.IGNORECASE|re.DOTALL):
        attributes=item[0]
        content=item[1].strip()
        attrs={}
        for attr in re.findall(r"([^\"']*?)\s*=\s*\"([^\"]*?)\"", attributes, re.IGNORECASE|re.DOTALL):
            attrs[attr[0].strip()]=attr[1].strip()
        for attr in re.findall(r"([^\"']*?)\s*=\s*\'([^\']*?)\'", attributes, re.IGNORECASE|re.DOTALL):
            attrs[attr[0].strip()]=attr[1].strip()
        ret.append({"content":content,"attributes":attrs})
    if(len(ret)==0):
        p=r"<\s*"+tag+"\s*([^>]*?)\/s*>"
        for item in re.findall(p, content, re.IGNORECASE|re.DOTALL):
            attributes=item
            attrs={}
            for attr in re.findall(r"([^\"']*?)\s*=\s*\"([^\"]*?)\"", attributes, re.IGNORECASE|re.DOTALL):
                attrs[attr[0].strip()]=attr[1].strip()
            for attr in re.findall(r"([^\"']*?)\s*=\s*\'([^\']*?)\'", attributes, re.IGNORECASE|re.DOTALL):
                attrs[attr[0].strip()]=attr[1].strip()
            ret.append({"content":"","attributes":attrs})
        
    if(len(ret)==0):
        p=r"<\s*"+tag+"\s*([^>]*?)\s*>"
        for item in re.findall(p, content, re.IGNORECASE|re.DOTALL):
            attributes=item
            attrs={}
            for attr in re.findall(r"([^\"']*?)\s*=\s*\"([^\"]*?)\"", attributes, re.IGNORECASE|re.DOTALL):
                attrs[attr[0].strip()]=attr[1].strip()
            for attr in re.findall(r"([^\"']*?)\s*=\s*\'([^\']*?)\'", attributes, re.IGNORECASE|re.DOTALL):
                attrs[attr[0].strip()]=attr[1].strip()
            ret.append({"content":"","attributes":attrs})
        
        
    return ret

from io import StringIO

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        return infourl
    http_error_300 = http_error_302
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302

USER_AGENT="Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0"

class Parser():
    def __init__(self, main_url):
        self.cookiejar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cookiejar))
        self.opener_no_redirect = urllib.request.build_opener(NoRedirect(),urllib.request.HTTPCookieProcessor(self.cookiejar))
        
        self.main_url=main_url
    
    def getOpener(self, options={}):
        self.opener.addheaders = [('User-Agent', USER_AGENT)]
        for key in options:
            self.opener.addheaders.append((key,options[key]))
        return self.opener

    def getOpenerNoRedirect(self, options={}):
        self.opener_no_redirect.addheaders = [('User-Agent', USER_AGENT)]
        for key in options:
            self.opener_no_redirect.addheaders.append((key,options[key]))
        return self.opener_no_redirect
        
    def read(self, url, options={}, data=None):
        response=self.getOpener(options=options).open(url, data)
        ret=""
        try:
            content_length=(int)(response.info().get('Content-Length'))
        except:
            content_length=None
        bytes_read=0
        if(response.info().get('Content-Encoding')=="gzip"):
            f = gzip.GzipFile(fileobj=StringIO(response.read()))
            ret = f.read()
        else:
            while(True):
                r = response.read()
                if(content_length is None):
                    ret=r
                    break
                else:
                    bytes_read+=len(r)
                    ret+=r
                    if(bytes_read<content_length):
                        options["Range"]="bytes=%d-%d"%(bytes_read,content_length)
                        response.close()
                        response=self.getOpener(options=options).open(url, data)
                    else:
                        break
                    
        response.close()
        return ret
    
    def readAndGetLocation(self, url, options={}, data=None):
        loc=None
        response=self.getOpenerNoRedirect(options=options).open(url, data)
        if(response.getcode()==302 or response.getcode()==301):
            loc=response.headers.get("Location")
            response.close()
            ret=self.read(loc,options,data)
        else:
            if(response.info().get('Content-Encoding')=="gzip"):
                f = gzip.GzipFile(fileobj=StringIO(response.read()))
                ret = f.read()
            else:
                ret = response.read()        
            response.close()
        return (loc,ret)


    def getJSFunctionBody(self,content,fun,pos):
        for i,c in enumerate(content[pos:]):
            if c=="{":
                pos_start=pos+i
                counter=0
                for i,c in enumerate(content[pos_start:]):
                    if c=="{":
                        counter+=1
                    if c=="}":
                        counter-=1
                        if(counter==0):
                            pos_end=pos_start+i+1
                            return content[pos_start:pos_end]
        return None
        
    def getHostUrl(self, url):
        parsed_url=urllib.parse.urlparse(url)
        return parsed_url.scheme+"://"+parsed_url.netloc
    
    def getFullUrl(self, url, base_url):
        if(url is not None and url.startswith("//")):
            return "http:"+url
        elif(url is not None and url.startswith("/")):
            return self.getHostUrl(base_url)+url
        else:
            return url

class YoutubeParser(Parser):
    def __init__(self, main_url):
        Parser.__init__(self,main_url)
        self.sequence_cache={}

    def getAdaptiveStreamMap(self, content):
        for item in re.compile(r'"\s*adaptive_fmts\s*":"(.[^"]*)?', re.IGNORECASE|re.DOTALL).findall(content):
            return str(item).replace("\\u0026","&")
        return None

    def getFmtStreamMap(self, content):
        for item in re.compile(r'"\s*url_encoded_fmt_stream_map\s*":"(.[^"]*)?', re.IGNORECASE|re.DOTALL).findall(content):
            return str(item).replace("\\u0026","&")
        return None

    def getPlayerResponse(self, content):
        for item in re.compile(r'"\s*player_response\s*":"(.*?)[,]\"', re.IGNORECASE|re.DOTALL).findall(content):
            r=str(item).replace("\\\"",'"').replace("\\/","/").replace("\\\\","\\")
            if(r.endswith('"')):
                r=r[:-1]
            return r
        return None

    def getPlayerBaseUrl(self, content):
        for s in findall("script",content):
            if("src" in s["attributes"] and s["attributes"]["src"].find("base.js")>-1):
                return getFullUrl(s["attributes"]["src"],self.main_url)
        return None            

    def getHlsManifestUrl(self, content):
        for item in re.compile(r'\\"\s*hlsManifestUrl\s*\\":\\"(.[^"]*)?\\"', re.IGNORECASE|re.DOTALL).findall(content):
            return str(item).replace("\\u0026","&").replace("\/","/")
        return None    
    
    def isMP4Itag(self, itag):
        return itag in[18, 22, 37, 38, 82, 83, 84, 85]
    def getItagVideoResolution(self, itag):
        res = {
            18 : 360,
            22 : 720,
            37 : 1080,
            38 : 3072,
            82 : 360,
            83 : 240,
            84 : 720,
            85 : 520,
        }
        if itag in res:
            return res[itag]
        else:
            return "";
                
    def getItagCodecs(self, itag):
        if(itag in[18, 22, 37, 38, 82, 83, 84, 85]):
            return self.getItagVideoResolution(itag)
        else:
            return "Unknown format"
    
    def decryptSignature(self,player_base_url, signature):
        
        if(player_base_url not in self.sequence_cache):
            self.loadSequence(player_base_url)
        else:
            pass
        signature=list(signature)
        for fun,par in self.sequence_cache[player_base_url]:
            signature=fun(signature, (int)(par))
        signature="".join(signature)
        return quote_plus(signature)        
    
    def youtube_len(self,arr, len):
        return arr[len:]

    def youtube_index(self,arr, index):
        _local4 = arr[0];
        _local5 = arr[index % len(arr)];
        arr[0] = _local5;
        arr[index] = _local4;
        return arr;
    
    def youtube_reserved(self,arr, reserved):
        return arr[::-1]
        
    def loadSequence(self,player_base_url):
        sequence=[]
        try:
            content=self.read(player_base_url)
            for item in re.compile(r';\s*(.[^ {}]*?)\s*=\s*function\s*[(](.[^\)]*)?\s*[)]\s*[{](.[^{}]*?)\s*return (.[^\.]*?)[.]join\(""\)\s*}\s*;',re.IGNORECASE|re.DOTALL).findall(content):
                if(item[2].find("split")==-1):
                    continue
                f=item[0]
                for sig_fun in re.compile(r';\s*'+f+'\s*=\s*function\s*[(](.[^\)]*)?\s*[)]\s*[{](.[^{}]*?)\s*}',re.DOTALL).findall(content):
                    body_sig_fun=sig_fun[1]
                    for f in body_sig_fun.split(";"):
                        if(f.find("return")==0 and len(sequence)>0):
                            self.sequence_cache[player_base_url]=sequence
                            return

                        for dec_fun in re.compile(r'(.[^\(]*)?\s*[(]\s*(.[^\,]*)?\s*[,]\s*(.[^\)]*)?[)]',re.IGNORECASE|re.DOTALL).findall(f):
                            dec_fun_name=dec_fun[0]
                            dec_fun_par1=dec_fun[1]
                            dec_fun_par2=dec_fun[2]
                            body_dec_fun_list=[]
                            
                            for dec_fun1 in re.compile(''+dec_fun_name.split(".")[-1]+'\s*:\s*function\s*[(](.[^,)]*)?\s*[)]\s*[{](.[^{}]*?)\s*}',re.IGNORECASE|re.DOTALL).findall(content):
                                body_dec_fun_list.append(dec_fun1[1])
                            for dec_fun1 in re.compile(''+dec_fun_name.split(".")[-1]+'\s*:\s*function\s*[(](.[^,)]*)?\s*[,](.[^,)]*)?\s*[)]\s*[{](.[^{}]*?)\s*}',re.IGNORECASE|re.DOTALL).findall(content):
                                body_dec_fun_list.append(dec_fun1[2])
                            found=False
                            for body_dec_fun in body_dec_fun_list:    
                                if(body_dec_fun.find("length")>-1):
                                    sequence.append((self.youtube_index,dec_fun_par2))
                                    found=True
                                    break
                                elif(body_dec_fun.find("splice")>-1):
                                    sequence.append((self.youtube_len,dec_fun_par2))
                                    found=True
                                    break
                                elif(body_dec_fun.find("reverse")>-1):
                                    sequence.append((self.youtube_reserved,dec_fun_par2))
                                    found=True
                                    break
                            if(found is False):
                                raise Exception("Unknown fun "+dec_fun_name+" "+str(body_dec_fun_list))
                break
        except Exception as e:
            pass
        self.sequence_cache[player_base_url]=sequence
    
    def _parseStreams(self,adaptive_fmt_stream,url_encoded_fmt_stream_map,player_response,player_base_url,ret):
        adaptive_video_webm=[]
        adaptive_video_mp4=[]
        adaptive_audio_vorbis=[]
        adaptive_audio_mp4=[]
        if(adaptive_fmt_stream is not None):
            for p1 in adaptive_fmt_stream.split(","):
                url=None
                signature=None
                itag=None
                _type=None
                _l=None
                bitrate=None
                duration=None
                sp="signature"
                for p2 in p1.split("&"):
                    dat=p2.split("=")
                    if(dat[0]=="url"):
                        url=unquote_plus(dat[1])
                    if(dat[0]=="bitrate"):
                        bitrate=int(dat[1])
                    if(dat[0]=="itag"):
                        itag=int(dat[1])
                    if(dat[0]=="type"):
                        _type=unquote_plus(dat[1])
                    if(dat[0]=="s"):
                        signature=unquote_plus(dat[1])
                    if(dat[0]=="quality_label"):
                        _l=unquote_plus(dat[1])
                    if(dat[0]=="sp"):
                        sp=unquote_plus(dat[1])
                if(url is None):
                    continue
                
                if(signature != None):
                    url=url+"&"+sp+"="+self.decryptSignature(player_base_url, signature)
                
                for name, value in urllib.parse.parse_qsl(url):
                    if(name=="dur"):
                        duration=(float)(value)
                        break
                if(duration is not None and duration==0):
                    continue

        def bitrateComparator(x, y):
            try:
                ct1=x["bitrate"]
                ct2=y["bitrate"]
                return (int)(ct2-ct1)
            except:
                return 0
        if(len(adaptive_audio_vorbis)>1):
            adaptive_audio_vorbis=sorted(adaptive_audio_vorbis, cmp=bitrateComparator)
        if(len(adaptive_audio_mp4)>1):
            adaptive_audio_mp4=sorted(adaptive_audio_mp4, cmp=bitrateComparator)

        for video in adaptive_video_webm:
            audio_text=""
            if(len(adaptive_audio_vorbis)>0):
                audio=adaptive_audio_vorbis[0]
                audio_text="VORBIS"            
            elif(len(adaptive_audio_mp4)>0):
                audio=adaptive_audio_mp4[0]
                audio_text="MP4"            
            else:
                continue
            ret["result"].append({"seekable":False,"download_service_type":"adaptive","title":"WEBM/"+audio_text+" "+video["quality_label"] ,"url":video["url"]+"|"+audio["url"],"itag":video["itag"],"service_type":"adaptive","duration":video["duration"] })
        
        for video in adaptive_video_mp4:
            audio_text=""
            if(len(adaptive_audio_mp4)>0):
                audio=adaptive_audio_mp4[0]
                audio_text="MP4"            
            elif(len(adaptive_audio_vorbis)>0):
                audio=adaptive_audio_vorbis[0]
                audio_text="VORBIS"            
            else:
                continue
            ret["result"].append({"seekable":False,"download_service_type":"adaptive","title":"MP4/"+audio_text+" "+video["quality_label"] ,"url":video["url"]+"|"+audio["url"],"itag":video["itag"],"service_type":"adaptive","duration":video["duration"] })
            
        if(url_encoded_fmt_stream_map is None):
            return ret
        temp=[]
        for p1 in url_encoded_fmt_stream_map.split(","):
            url=None
            signature=None
            itag=None
            _type=None
            _l=None
            sp="signature"
            for p2 in p1.split("&"):
                dat=p2.split("=")
                if(dat[0]=="url"):
                    url=unquote_plus(dat[1])
                if(dat[0]=="itag"):
                    itag=int(dat[1])
                if(dat[0]=="type"):
                    _type=unquote_plus(dat[1])
                if(dat[0]=="s"):
                    signature=unquote_plus(dat[1])
                if(dat[0]=="quality_label"):
                    _l=unquote_plus(dat[1])
                if(dat[0]=="sp"):
                    sp=unquote_plus(dat[1])
            if(url != None and self.isMP4Itag(itag)):
                if(signature != None):
                    url=url+"&"+sp+"="+self.decryptSignature(player_base_url, signature)
                itag_codecs=self.getItagCodecs(itag)
                temp.append({"title":"MP4 "+str(itag_codecs)+"p","url":url,"itag":itag_codecs})
        ret["result"].extend(sorted(temp,key=lambda k: k['itag'],reverse=True))
        
        return ret        
        
    def getPlayList(self, url, referer=None):
        content=self.read(url)
        ret={}
        ret["type"]="single"
        ret["result"]=[]
        
        player_base_url=self.getPlayerBaseUrl(content)
        adaptive_fmt_stream=self.getAdaptiveStreamMap(content)
        url_encoded_fmt_stream_map=self.getFmtStreamMap(content)
        player_response=self.getPlayerResponse(content)
        try:
            player_response=json.loads(player_response)
        except:
            player_response=None
        if(player_response is not None and "streamingData" in player_response):
            if(adaptive_fmt_stream is None and "adaptiveFormats" in player_response["streamingData"]):
                temp=[]
                for f in player_response["streamingData"]["adaptiveFormats"]:
                    itag=f["itag"]
                    if("qualityLabel" in f):
                        quality_label=f["qualityLabel"]
                    else:
                        quality_label=""
                    bitrate=f["bitrate"]
                    _type=f["mimeType"]
                    _url=""
                    if("cipher" not in f):
                        f["cipher"]=""
                        if("url" in f):
                            _url="&url="+quote_plus(f["url"])
                            
                    temp.append(f["cipher"]+"&itag="+str(itag)+_url+"&quality_label="+quote_plus(quality_label)+"&type="+quote_plus(_type)+"&bitrate="+quote_plus(str(bitrate)))
                if(len(temp)>0):
                    adaptive_fmt_stream=",".join(temp)

            if(url_encoded_fmt_stream_map is None and "formats" in player_response["streamingData"]):
                temp=[]
                for f in player_response["streamingData"]["formats"]:
                    _url=""
                    if("cipher" not in f):
                        f["cipher"]=""
                        if("url" in f):
                            _url="&url="+quote_plus(f["url"])
                    itag=f["itag"]
                    quality_label=f["qualityLabel"]
                    temp.append(f["cipher"]+"&itag="+str(itag)+_url+"&quality_label="+quality_label)
                if(len(temp)>0):
                    url_encoded_fmt_stream_map=",".join(temp)
        self._parseStreams(adaptive_fmt_stream,url_encoded_fmt_stream_map,player_response,player_base_url,ret)
        return ret
    
def generatePlayList(url):
    parser=YoutubeParser("https://youtube.com")
    for _ in range(10):
        try:
            urls = parser.getPlayList(url)
            if urls['result'] != []:
                return urls['result'][0]['url']
        except Exception as e:
            pass
    return None



#movie = 'https://www.youtube.com/watch?v=kXpjF1qtpt0'
#movie = 'https://www.youtube.com/watch?v=Up4WjdabA2c'
#movie = 'https://www.youtube.com/watch?v=aQUlA8Hcv4s'
#movie = 'https://www.youtube.com/watch?v=JCsJWKlMD0g&t=2s'
#movie = 'https://www.youtube.com/watch?v=Up4WjdabA2c'
#movie = 'https://www.youtube.com/watch?v=rAKI1JEz6Z8'
#movie = 'https://www.youtube.com/watch?v=22nXyKzXtfw'
#print generatePlayList(movie)


class youtube_url:

    def get_youtube_link2(self, url):
        url = generatePlayList(url)
        if url:
            return url
        else:
            return ''
        """video_tulpe = []
        film_quality = []
        video_id = ''
        video_url = url
        error = None
        if url.find('youtube') > -1:
            split = video_url.split('=')
            if len(split) > 1:
                video_id = split[1]
                video_url = None
                try:
                    answer = (urlopen(Request('http://91.211.245.49/youtube/youtube_api.php?id=' + video_id, None, {'User-agent': 'Mozilla/5.0 nStreamVOD 0.1', 'Connection': 'Close'})).read())
                    
                    reg = re.findall('<iframe src="(.*?)" quality="(.*?)">', answer)
                    for src, quality in reg:
                        if quality.find('webm') < 1 and quality.find('flv') < 1  and quality.find('vp8') < 1  and quality.find('h.263') < 1:
                            video_tulpe.append(src)
                            film_quality.append(quality)
                    #print video_tulpe, film_quality
                    if video_tulpe != [] and film_quality != []:
                        return ('', video_tulpe, film_quality)
                    else:
                        return ('No Youtube video', [], [])
                except Exception as ex:
                    return ('No Youtube video', [], [])"""





