# -*- coding: utf-8 -*-
import urllib.request, urllib.error, urllib.parse
import os, re


def best_m3u8(url):

    video_tulpe = []
    url_main = ''
    film_quality = []
    try:
        url_split = url.split('/')[:-1]
        for url_frag in url_split:
            url_main = url_main + (url_frag + '/')
        req = urllib.request.Request(url, data = None, headers = {'User-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0'})
        resp = urllib.request.urlopen(req)
        page = resp.read()
        quality = re.findall('BANDWIDTH=([0-9]+)', page)
        video = re.findall('BANDWIDTH=.*\s(.*)', page)
        if quality != [] and video != []:
            i = -1
            tulpe = []
            for tulp in video:
                i += 1
                if video[0].find('http') < 0:
                    compl = (int(quality[i]), url_main + tulp)
                else:
                    compl = (int(quality[i]), tulp)
                tulpe.append(compl)

            tulpeSort = sorted(tulpe, reverse=True)
            for rev in tulpeSort:
                film_quality.append(str(rev[0]))
                video_tulpe.append(rev[1])
            url = video_tulpe[0]
    except Exception as ex:
        print('error m3u8', ex)
        return url
        
    return(url)



